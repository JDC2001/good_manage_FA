package com.wms.service;

import com.wms.entity.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author wms
 * @since 2022-10-04
 */
public interface MenuService extends IService<Menu> {

}
